# E - commerce empresa X

Vamos criar um ecommerce para o **COMPASSUOL**, *repositorio* X

## Funcionalidades: 
_Chekcout **Tela de Produto** Catalogo home_,


**Chekcout _Tela de Produto_ Catalogo home**
###### Melhorias de projeto
__Melhoria_1__, _melhoria_2_

### Linguagens do Projeto:

* HTML
* CSSS
* Python
* C
* C#
* JavaScript

### Funcionaliades a desenvolver:
1. Aréa de Mensagem.
    1. Posso criar listas alinhadas como subtarefas por exemplo.
    2. Gostando Bastante o curso de git.
    3. Estágio UOL.
2. To aprendendo Bastante.
3. Eu amo softwre, a área que mais gosto.


#### Imagem Local ATL


![Foto minha](IMG/ssa.png)


#### Imagem Externa
![ike south park](https://static.wikia.nocookie.net/southpark/images/a/af/Ike-current.png/revision/latest?cb=20180521124521)


## links 

[Google](https://www.google.com)

[UTFPR](https://http://www.utfpr.edu.br/campus/doisvizinhos)



[![ike south park](https://static.wikia.nocookie.net/southpark/images/a/af/Ike-current.png/revision/latest?cb=20180521124521)](https://http://www.utfpr.edu.br/campus/doisvizinhos)

### Lista de tarefas a fazer:

- [x] Tarefas completadas.
- [ ] Tarefas a fazer.
- [ ] Bonus.
- [x] PHP.
